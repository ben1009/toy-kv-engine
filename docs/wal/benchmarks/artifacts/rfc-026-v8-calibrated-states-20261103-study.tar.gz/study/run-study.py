"""Fixed native campaign orchestration; no instrumentation or tuning changes."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

study = Path('target/rfc-026-v8-calibrated-states-20261103-v2')
binary = 'target/rfc-026-v8-wal-extents-20261103/write-perf-extents'
scripts = Path('docs/wal/benchmarks')
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'


def unprivileged():
    os.setgroups([])
    os.setgid(1000)
    os.setuid(1000)


def receipt(name, data):
    path = study / name
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')
    os.chown(path, 1000, 1000)


receipt('execution.json', {'orchestrator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                         'started_monotonic_ns': time.monotonic_ns(), 'started_unix_ns': time.time_ns(),
                         'phases': ['training', 'validation', 'freeze', 'evaluation'],
                         'raw_device_writes': False, 'device_settings_changed': False})
for phase in ('training', 'validation', 'evaluation'):
    if phase == 'evaluation':
        subprocess.run(['/usr/bin/python3', '-B', str(scripts / 'wal_state_calibration.py'), 'fit',
                        '--study-dir', str(study), '--training', str(study / 'training'),
                        '--validation', str(study / 'validation')], check=True, preexec_fn=unprivileged)
        receipt('evaluation-admission.json', {'model_sha256': hashlib.sha256((study / 'frozen-model.json').read_bytes()).hexdigest(),
                                             'monotonic_ns': time.monotonic_ns(), 'unix_ns': time.time_ns()})
    print(json.dumps({'phase': phase, 'status': 'capture_start'}), flush=True)
    subprocess.run(['/usr/bin/python3', '-B', str(scripts / 'capture_wal_trace.py'),
                    '--binary', binary, '--output-dir', str(study / phase), '--wal-extents',
                    '--counter-interval-ms', '100', '--cpus', '0-15', '--uid', '1000', '--gid', '1000'], check=True)
    print(json.dumps({'phase': phase, 'status': 'offline_analysis_start'}), flush=True)
    subprocess.run(['/usr/bin/python3', '-B', str(scripts / 'wal_extent_trace.py'),
                    '--capture-dir', str(study / phase)], check=True, preexec_fn=unprivileged)
subprocess.run(['/usr/bin/python3', '-B', str(scripts / 'wal_state_calibration.py'), 'evaluate',
                '--study-dir', str(study), '--evaluation', str(study / 'evaluation')], check=True, preexec_fn=unprivileged)
print(json.dumps({'status': 'study_complete'}), flush=True)
