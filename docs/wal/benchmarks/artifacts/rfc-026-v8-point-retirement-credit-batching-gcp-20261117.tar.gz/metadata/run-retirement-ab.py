#!/usr/bin/env python3
import json
import os
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone
from statistics import median

ROOT = Path('/mnt/test-ssd/work/retirement-batch')
BINARY = ROOT / 'target/release/write-perf'
RESULTS = Path('/mnt/test-ssd/results/retirement-batch-20261117-corrected')
DB_ROOT = ROOT / 'db'
BASE_ENV = {
    'TOYKV_BENCH_V8_EXTENT_PREP': 'sliding-point-lookahead',
    'TOYKV_BENCH_V8_EXTENT_PREP_BYTES': '1048576',
    'TOYKV_WAL_V8_FRONTIER_MODE': 'direct',
}
BASE_ARGS = [
    str(BINARY), '--bench', 'wal_concurrent', '--wal', '--pitr', '--pitr-format', 'v8',
    '--wal-io-mode', 'parallel', '--num', '100000', '--threads', '16',
    '--value-size', '1024', '--target-sst-size', '2147483648',
    '--compaction', 'none', '--output', 'json', '--latency-sample-every', '100',
]

RESULTS.mkdir(parents=True, exist_ok=False)
DB_ROOT.mkdir(parents=True, exist_ok=True)

def write_json(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n', encoding='utf-8')

runs_started = 0
def run_one(run_id, enabled, *, batch_entries=None, diagnostic=False):
    global runs_started
    runs_started += 1
    write_json(RESULTS / 'remote-exit.json', {'failed': True, 'runs_started': runs_started, 'planned_runs': 16, 'state': 'in_progress'})
    run_dir = RESULTS / run_id
    run_dir.mkdir()
    env = dict(os.environ)
    env.pop('TOYKV_WAL_V8_COALESCE_BUDGET_US', None)
    env.update(BASE_ENV)
    env['TOYKV_BENCH_V8_POINT_FRONTIER_CREDIT_BATCH'] = '1' if enabled else '0'
    args = list(BASE_ARGS)
    args[2] = 'wal_batch_concurrent' if batch_entries is not None else 'wal_concurrent'
    if batch_entries is not None:
        args.extend(['--wal-batch-size', str(batch_entries)])
    if diagnostic:
        args.extend(['--wal-v8-durability-sample-every', '64'])
    args.extend(['--path', str(DB_ROOT / run_id)])
    metadata = {
        'run_id': run_id,
        'workload': 'batch' if batch_entries is not None else 'point',
        'batch_entries': batch_entries,
        'credit_batch_enabled': enabled,
        'durability_sampler_enabled': diagnostic,
        'sample_every': 64 if diagnostic else None,
        'extent_mode': BASE_ENV['TOYKV_BENCH_V8_EXTENT_PREP'],
        'extent_window_bytes': 1048576,
        'frontier_mode': BASE_ENV['TOYKV_WAL_V8_FRONTIER_MODE'],
        'coalescing_override': None,
        'started_utc': datetime.now(timezone.utc).isoformat(),
        'argv': args,
        'env': {k: env[k] for k in (*BASE_ENV.keys(), 'TOYKV_BENCH_V8_POINT_FRONTIER_CREDIT_BATCH')},
    }
    write_json(run_dir / 'run-metadata.json', metadata)
    start = time.monotonic()
    completed = subprocess.run(
        ['timeout', '--signal=INT', '--kill-after=30s', '900', 'env', *[f'{k}={v}' for k, v in metadata['env'].items()], *args],
        cwd=ROOT / 'source-with-metric-export',
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False, env=env,
    )
    elapsed = time.monotonic() - start
    (run_dir / 'result.json').write_text(completed.stdout, encoding='utf-8')
    (run_dir / 'stderr.log').write_text(completed.stderr, encoding='utf-8')
    metadata['ended_utc'] = datetime.now(timezone.utc).isoformat()
    metadata['wall_seconds'] = elapsed
    metadata['exit_code'] = completed.returncode
    if completed.returncode != 0:
        write_json(run_dir / 'run-metadata.json', metadata)
        raise RuntimeError(f'{run_id} exited with {completed.returncode}')
    report = json.loads(completed.stdout)
    result = report['result']
    pipeline = result['wal_pipeline']
    ops = int(result['ops'])
    sync_count = int(pipeline['sync_count'])
    cpu_seconds = (float(result['process_cpu_user_ms']) + float(result['process_cpu_system_ms'])) / 1000.0
    metrics = {
        'ops': ops,
        'ops_per_sec': float(result['ops_per_sec']),
        'cpu_seconds': cpu_seconds,
        'cpu_us_per_op': cpu_seconds * 1_000_000 / ops,
        'sync_count': sync_count,
        'ops_per_sync': ops / sync_count if sync_count else None,
        'p50_ms': float(report['latency']['p50_ms']),
        'p95_ms': float(report['latency']['p95_ms']),
        'p99_ms': float(report['latency']['p99_ms']),
    }
    diagnostics = pipeline.get('v8_durability_diagnostics')
    if diagnostics is not None:
        phases = diagnostics.get('phases', [])
        metrics['sampled_advances'] = diagnostics.get('sampled_advances')
        metrics['batched_point_credit_advances'] = sum(
            phase.get('resource_retire_before_publish_batched_point_credits') is True for phase in phases
        )
        metrics['retirement_release_cpu_ns_p50'] = median(
            [phase['resource_retire_before_publish_release_cpu_ns'] for phase in phases]
        ) if phases else None
        metrics['retirement_tickets_p50'] = median(
            [phase['resource_retire_before_publish_tickets'] for phase in phases]
        ) if phases else None
        metrics['phase_count'] = len(phases)
    if ops != 100000:
        raise RuntimeError(f'{run_id} returned unexpected operation count')
    metadata['success'] = True
    metadata['metrics'] = metrics
    write_json(run_dir / 'run-metadata.json', metadata)
    print(json.dumps({'completed': run_id, 'ops_per_sec': metrics['ops_per_sec'], 'cpu_us_per_op': metrics['cpu_us_per_op'], 'sync_count': metrics['sync_count']}, sort_keys=True), flush=True)
    return {'run_id': run_id, **metrics}

planned = 16
planned_ids = [f'point-pair-{pair:02d}-{arm}' for pair in range(1, 6) for arm in ('off', 'on')] + ['point-diagnostic-off', 'point-diagnostic-on'] + [f'batch{size}-diagnostic-{arm}' for size in (16, 64) for arm in ('off', 'on')]
summary = {'planned_runs': planned, 'completed_runs': 0, 'complete': False, 'planned_run_ids': planned_ids, 'runs': []}
write_json(RESULTS / 'run-plan.json', {'planned_runs': planned, 'run_ids': planned_ids, 'point_score': {'writers': 16, 'puts': 100000, 'value_bytes': 1024, 'pairs': 5}, 'extent_mode': BASE_ENV['TOYKV_BENCH_V8_EXTENT_PREP'], 'extent_window_bytes': 1048576, 'frontier_mode': BASE_ENV['TOYKV_WAL_V8_FRONTIER_MODE'], 'sampling': {'score_latency_every': 100, 'durability_every': 64}})
write_json(RESULTS / 'remote-exit.json', {'failed': True, 'runs_started': 0, 'planned_runs': planned, 'state': 'in_progress'})
write_json(RESULTS / 'summary.json', summary)
score = []
for pair in range(1, 6):
    arms = [('off', False), ('on', True)] if pair % 2 == 1 else [('on', True), ('off', False)]
    for arm, enabled in arms:
        record = run_one(f'point-pair-{pair:02d}-{arm}', enabled)
        score.append({'pair': pair, 'arm': arm, **record})
        summary['runs'].append(record)
        summary['completed_runs'] += 1
        write_json(RESULTS / 'summary.json', summary)
        time.sleep(2)

point_diag = []
for arm, enabled in [('off', False), ('on', True)]:
    record = run_one(f'point-diagnostic-{arm}', enabled, diagnostic=True)
    point_diag.append({'arm': arm, **record})
    summary['runs'].append(record)
    summary['completed_runs'] += 1
    write_json(RESULTS / 'summary.json', summary)

batch_diag = []
for batch_size in (16, 64):
    for arm, enabled in [('off', False), ('on', True)]:
        record = run_one(f'batch{batch_size}-diagnostic-{arm}', enabled, batch_entries=batch_size, diagnostic=True)
        batch_diag.append({'batch_size': batch_size, 'arm': arm, **record})
        summary['runs'].append(record)
        summary['completed_runs'] += 1
        write_json(RESULTS / 'summary.json', summary)

pair_deltas = []
for pair in range(1, 6):
    off = next(x for x in score if x['pair'] == pair and x['arm'] == 'off')
    on = next(x for x in score if x['pair'] == pair and x['arm'] == 'on')
    pair_deltas.append((on['ops_per_sec'] / off['ops_per_sec'] - 1.0) * 100.0)
summary['score'] = {
    'off_median_ops_per_sec': median(x['ops_per_sec'] for x in score if x['arm'] == 'off'),
    'on_median_ops_per_sec': median(x['ops_per_sec'] for x in score if x['arm'] == 'on'),
    'paired_delta_pct': pair_deltas,
    'paired_delta_median_pct': median(pair_deltas),
    'paired_wins': sum(delta > 0 for delta in pair_deltas),
    'off_median_cpu_us_per_op': median(x['cpu_us_per_op'] for x in score if x['arm'] == 'off'),
    'on_median_cpu_us_per_op': median(x['cpu_us_per_op'] for x in score if x['arm'] == 'on'),
    'off_median_ops_per_sync': median(x['ops_per_sync'] for x in score if x['arm'] == 'off'),
    'on_median_ops_per_sync': median(x['ops_per_sync'] for x in score if x['arm'] == 'on'),
    'off_median_p50_ms': median(x['p50_ms'] for x in score if x['arm'] == 'off'),
    'on_median_p50_ms': median(x['p50_ms'] for x in score if x['arm'] == 'on'),
    'off_median_p95_ms_sampled': median(x['p95_ms'] for x in score if x['arm'] == 'off'),
    'on_median_p95_ms_sampled': median(x['p95_ms'] for x in score if x['arm'] == 'on'),
    'off_median_p99_ms_sampled': median(x['p99_ms'] for x in score if x['arm'] == 'off'),
    'on_median_p99_ms_sampled': median(x['p99_ms'] for x in score if x['arm'] == 'on'),
}
summary['point_diagnostics'] = point_diag
summary['batch_diagnostics'] = batch_diag
if summary['completed_runs'] != planned:
    raise RuntimeError('planned/completed run count mismatch')
if point_diag[0]['phase_count'] == 0 or point_diag[1]['phase_count'] == 0:
    raise RuntimeError('Point diagnostic samples missing')
if point_diag[0]['batched_point_credit_advances'] != 0:
    raise RuntimeError('batch-disable Point diagnostic unexpectedly batched credits')
if point_diag[1]['batched_point_credit_advances'] == 0:
    raise RuntimeError('batch-enable Point diagnostic did not exercise batched credits')
if any(row['batched_point_credit_advances'] != 0 for row in batch_diag):
    raise RuntimeError('Batch diagnostic unexpectedly entered Point-only credit batching')
for run_id in planned_ids:
    d = RESULTS / run_id
    m = json.loads((d / 'run-metadata.json').read_text())
    if not (d / 'result.json').is_file() or not m.get('success'):
        raise RuntimeError(f'missing or unsuccessful result pair: {run_id}')
if runs_started != planned:
    raise RuntimeError('started/planned run count mismatch')
summary['complete'] = True
summary['validation'] = {
    'point_off_has_no_batched_credit_advances': True,
    'point_on_has_batched_credit_advances': True,
    'batch16_and_batch64_never_batched_point_credits': True,
}
write_json(RESULTS / 'summary.json', summary)
write_json(RESULTS / 'remote-exit.json', {'failed': False, 'runs_started': runs_started, 'planned_runs': planned, 'exit_code': 0})
print(json.dumps({'complete': summary['complete'], 'planned_runs': planned,
                  'completed_runs': summary['completed_runs'], 'score': summary['score'],
                  'point_diag_batched_advances': [x['batched_point_credit_advances'] for x in point_diag],
                  'batch_diag_batched_advances': [x['batched_point_credit_advances'] for x in batch_diag]}, sort_keys=True))
